#include "embeddinator.h"
#import <Foundation/Foundation.h>


#if !__has_feature(objc_arc)
#error Embeddinator code must be built with ARC.
#endif

#ifdef __cplusplus
extern "C" {
#endif
// forward declarations
@class Enums;
@class iOSPlatformProvider;
@class Listrak_ListrakClientBase2;
@class Listrak_ListrakCredentialsBase2;
@class ListrakAddress;
@class ListrakItem;
@class ListrakOrder;
@class ListrakSDK_iOS_Constants_Variables;
@class ListrakSDK_iOS_Models_Alert;
@class ListrakSDK_iOS_Models_APNS;
@class ListrakSDK_iOS_Models_Aps;
@class NotificationManager;
@class ListrakClient;
@class ListrakCredentials;


NS_ASSUME_NONNULL_BEGIN

/** Enumeration Enums_DiscountType
 *  Corresponding .NET Qualified Name: `Enums+DiscountType, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
typedef NS_ENUM(int, Enums_DiscountType) {
	Enums_DiscountTypeNotSet = 0,
	Enums_DiscountTypePriceOverride = 1,
	Enums_DiscountTypePriceRule = 2,
	Enums_DiscountTypePromotion = 3,
	Enums_DiscountTypeSeniorCitizen = 4,
	Enums_DiscountTypeMarkdown = 5,
	Enums_DiscountTypeCoupon = 6,
	Enums_DiscountTypeQuantityDiscount = 7,
	Enums_DiscountTypeRebate = 8,
	Enums_DiscountTypeCashDiscount = 9,
	Enums_DiscountTypeTradeDiscount = 10,
	Enums_DiscountTypeTradeInKind = 11,
	Enums_DiscountTypePromptPaymentDiscount = 12,
	Enums_DiscountTypeGeneralDiscount = 13,
	Enums_DiscountTypeGiftVoucher = 14,
	Enums_DiscountTypeFlexibleDiscount = 15,
	Enums_DiscountTypeRewardProgram = 16,
	Enums_DiscountTypeManufacturerReward = 17,
	Enums_DiscountTypeCreditCardReward = 18,
};

/** Enumeration Enums_SegmentationAction
 *  Corresponding .NET Qualified Name: `Enums+SegmentationAction, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
typedef NS_ENUM(int, Enums_SegmentationAction) {
	Enums_SegmentationActionUpdate = 0,
	Enums_SegmentationActionOverwrite = 1,
};

/** Enumeration Enums_Status
 *  Corresponding .NET Qualified Name: `Enums+Status, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
typedef NS_ENUM(int, Enums_Status) {
	Enums_StatusNotSet = 0,
	Enums_StatusMisc = 1,
	Enums_StatusPreOrder = 2,
	Enums_StatusBackOrder = 3,
	Enums_StatusPending = 4,
	Enums_StatusHold = 5,
	Enums_StatusProcessing = 6,
	Enums_StatusShipped = 7,
	Enums_StatusCompleted = 8,
	Enums_StatusReturned = 9,
	Enums_StatusCanceled = 10,
	Enums_StatusUnknown = 11,
	Enums_StatusClosed = 12,
};


/** Class Enums
 *  Corresponding .NET Qualified Name: `Enums, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface Enums : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;

/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class iOSPlatformProvider
 *  Corresponding .NET Qualified Name: `iOSPlatformProvider, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface iOSPlatformProvider : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


- (NSString *)getAppVersion;
- (NSString *)getDeviceToken;
- (NSString *)getDeviceTokenFromProvider;
- (NSString *)getHardwareID;
- (int)getOperatingSystem;
- (NSString *)getOperatingSystemVersion;
- (int)getPlatformType;
- (bool)getSystemNotificationsEnabled;
- (NSString *)getTrackingTokenUID;
- (bool)isAppInstall;
- (bool)isDeviceTokenChangedDeviceToken:(NSString *)deviceToken;
- (bool)isSubscriptionStatusChangedToEnabled;
- (void)saveTrackingTokenUIDTrackingTokenUID:(NSString *)trackingTokenUID;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class Listrak_ListrakClientBase2
 *  Corresponding .NET Qualified Name: `Listrak.ListrakClientBase2, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface Listrak_ListrakClientBase2 : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;


- (void)checkForNewSessionEvent;
- (void)enableOrDisableAppNotificationsEnable:(bool)enable;
- (NSString *)getHardwareID;
- (void)onAppInstall;
- (void)onEnterBackground;
- (void)onEnterForeground;
- (void)onNotificationClickPushsendID:(long long)pushsendID trackingTokenUID:(NSString *)trackingTokenUID;
- (void)postContentToApiEventAction:(int)eventAction appEventDTO:(NSString *)appEventDTO;
- (void)registerDeviceDeviceToken:(NSString *)deviceToken;
- (void)registerDeviceDeviceToken:(NSString *)deviceToken forceSubscribe:(bool)forceSubscribe;
- (void)registerDeviceInformation;
- (void)setMerchantIDMerchantID:(NSString *)merchantID;
- (void)setProfileFieldsSegmentationAction:(int)segmentationAction email:(NSString *)email firstName:(NSString *)firstName lastName:(NSString *)lastName phoneNumber:(long long)phoneNumber birthday:(NSString *)birthday postalCode:(NSString *)postalCode;
- (void)unsubscribeDevice;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class Listrak_ListrakCredentialsBase2
 *  Corresponding .NET Qualified Name: `Listrak.ListrakCredentialsBase2, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface Listrak_ListrakCredentialsBase2 : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)initWithClientID:(NSString *)clientID clientSecret:(NSString *)clientSecret;

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;

/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakAddress
 *  Corresponding .NET Qualified Name: `ListrakAddress, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakAddress : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic) NSString *address1;
@property (nonatomic) NSString *address2;
@property (nonatomic) NSString *address3;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *country;
@property (nonatomic) NSString *firstName;
@property (nonatomic) NSString *lastName;
@property (nonatomic) NSString *phone;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *zipCode;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakItem
 *  Corresponding .NET Qualified Name: `ListrakItem, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakItem : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic) NSString *discountDescription;
@property (nonatomic) double discountedPrice;
@property (nonatomic) int discountType;
@property (nonatomic) double itemTotal;
@property (nonatomic) NSString *meta1;
@property (nonatomic) NSString *meta2;
@property (nonatomic) NSString *meta3;
@property (nonatomic) NSString *meta4;
@property (nonatomic) NSString *meta5;
@property (nonatomic) NSString *orderNumber;
@property (nonatomic) double price;
@property (nonatomic) int quantity;
@property (nonatomic) NSString *shipDate;
@property (nonatomic) NSString *shippingMethod;
@property (nonatomic) NSString *sku;
@property (nonatomic) int status;
@property (nonatomic) NSString *trackingNumber;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakOrder
 *  Corresponding .NET Qualified Name: `ListrakOrder, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakOrder : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic) NSString *associateID;
@property (nonatomic) NSString *couponCode;
@property (nonatomic) NSString *customerNumber;
@property (nonatomic) NSDate *dateEntered;
@property (nonatomic) NSString *discountDescription;
@property (nonatomic) double discountTotal;
@property (nonatomic) int discountType;
@property (nonatomic) NSString *email;
@property (nonatomic) double handlingTotal;
@property (nonatomic) double itemTotal;
@property (nonatomic) NSString *meta1;
@property (nonatomic) NSString *meta2;
@property (nonatomic) NSString *meta3;
@property (nonatomic) NSString *meta4;
@property (nonatomic) NSString *meta5;
@property (nonatomic) NSString *orderNumber;
@property (nonatomic) double orderTotal;
@property (nonatomic) NSString *shipDate;
@property (nonatomic) NSString *shippingMethod;
@property (nonatomic) double shippingTotal;
@property (nonatomic) int status;
@property (nonatomic) NSString *storeNumber;
@property (nonatomic) double taxTotal;
@property (nonatomic) NSString *trackingNumber;

- (void)addItemOrderNumber:(NSString *)orderNumber sku:(NSString *)sku price:(double)price discountedPrice:(double)discountedPrice discountType:(int)discountType discountDescription:(NSString *)discountDescription quantity:(int)quantity itemTotal:(double)itemTotal status:(int)status shippingMethod:(NSString *)shippingMethod shipDate:(NSString *)shipDate trackingNumber:(NSString *)trackingNumber meta1:(NSString *)meta1 meta2:(NSString *)meta2 meta3:(NSString *)meta3 meta4:(NSString *)meta4 meta5:(NSString *)meta5;
- (void)setBillingAddressFirstName:(NSString *)firstName lastName:(NSString *)lastName address1:(NSString *)address1 address2:(NSString *)address2 address3:(NSString *)address3 city:(NSString *)city state:(NSString *)state zipCode:(NSString *)zipCode country:(NSString *)country phone:(NSString *)phone;
- (void)setShippingAddressFirstName:(NSString *)firstName lastName:(NSString *)lastName address1:(NSString *)address1 address2:(NSString *)address2 address3:(NSString *)address3 city:(NSString *)city state:(NSString *)state zipCode:(NSString *)zipCode country:(NSString *)country phone:(NSString *)phone;
- (void)submitOrder;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakSDK_iOS_Constants_Variables
 *  Corresponding .NET Qualified Name: `ListrakSDK.iOS.Constants.Variables, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakSDK_iOS_Constants_Variables : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic, class, readonly) NSString *pushCategory;
@property (nonatomic, class, readonly) NSString *pushSendID;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakSDK_iOS_Models_Alert
 *  Corresponding .NET Qualified Name: `ListrakSDK.iOS.Models.Alert, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakSDK_iOS_Models_Alert : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic) NSString *body;
@property (nonatomic) NSString *subtitle;
@property (nonatomic) NSString *title;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakSDK_iOS_Models_APNS
 *  Corresponding .NET Qualified Name: `ListrakSDK.iOS.Models.APNS, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakSDK_iOS_Models_APNS : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic) ListrakSDK_iOS_Models_Aps *aps;
@property (nonatomic) int sendID;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakSDK_iOS_Models_Aps
 *  Corresponding .NET Qualified Name: `ListrakSDK.iOS.Models.Aps, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakSDK_iOS_Models_Aps : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


@property (nonatomic) ListrakSDK_iOS_Models_Alert *alert;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class NotificationManager
 *  Corresponding .NET Qualified Name: `NotificationManager, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface NotificationManager : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


- (void)didReceiveMessageUserinfo:(NSString *)userinfo;
- (void)updateBadgeNumber;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakClient
 *  Corresponding .NET Qualified Name: `ListrakClient, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakClient : Listrak_ListrakClientBase2 {
}

- (nullable instancetype)initWithClientID:(NSString *)clientID clientSecret:(NSString *)clientSecret;

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;


@property (nonatomic, class) ListrakClient *instance;

- (void)enableOrDisableAppNotificationsEnable:(bool)enable;
- (NSString *)getHardwareID;
- (void)onAppInstall;
- (void)onEnterBackground;
- (void)onEnterForeground;
- (void)onMessageReceivedUserInfo:(NSString *)userInfo;
- (void)onNotificationClickPushsendID:(long long)pushsendID trackingTokenUID:(NSString *)trackingTokenUID;
- (void)registerDeviceDeviceToken:(NSString *)deviceToken;
- (void)registerDeviceDeviceToken:(NSString *)deviceToken forceSubscribe:(bool)forceSubscribe;
- (void)registerDeviceInformation;
- (void)setProfileFieldsSegmentationAction:(int)segmentationAction email:(NSString *)email firstName:(NSString *)firstName lastName:(NSString *)lastName phoneNumber:(long long)phoneNumber birthday:(NSString *)birthday postalCode:(NSString *)postalCode;
- (void)unsubscribeDevice;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakCredentials
 *  Corresponding .NET Qualified Name: `ListrakCredentials, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakCredentials : Listrak_ListrakCredentialsBase2 {
}

- (nullable instancetype)initWithClientID:(NSString *)clientID clientSecret:(NSString *)clientSecret;

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;

/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end

NS_ASSUME_NONNULL_END

#ifdef __cplusplus
} /* extern "C" */
#endif
